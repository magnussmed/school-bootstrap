TIME_TO_SEND = "00:13"

EMAIL_FROM = "din mail"
EMAIL_TO = "teacher mail"
PASS = "password til din mail"

SUBJECT = "Aye subject"
MESSAGE = '''
Hej lol xD

mega nicve
'''